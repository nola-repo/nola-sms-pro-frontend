<?php
/**
 * POST /api/auth/register
 * Registers a new Agency or User account.
 *
 * Payload: { firstName, lastName, email, phone, password, role: "agency"|"user" }
 * Response 201: { status: "success", message: "Account created." }
 */

require_once __DIR__ . '/../cors.php';
header('Content-Type: application/json');
require __DIR__ . '/../webhook/firestore_client.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

$firstName = trim($input['firstName'] ?? '');
$lastName  = trim($input['lastName']  ?? '');
$email     = strtolower(trim($input['email']  ?? ''));
$phone     = trim($input['phone']     ?? '');
$password  = $input['password']       ?? '';
$role      = $input['role']           ?? '';

// ── Validation ────────────────────────────────────────────────────────────────
if (!$firstName || !$lastName || !$email || !$phone || !$password || !$role) {
    http_response_code(422);
    echo json_encode(['error' => 'All fields are required.']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(422);
    echo json_encode(['error' => 'Invalid email address.']);
    exit;
}

if (!in_array($role, ['agency', 'user'], true)) {
    http_response_code(422);
    echo json_encode(['error' => 'Role must be "agency" or "user".']);
    exit;
}

if (strlen($password) < 8) {
    http_response_code(422);
    echo json_encode(['error' => 'Password must be at least 8 characters.']);
    exit;
}

try {
    $db = get_firestore();

    // ── Check duplicate email ────────────────────────────────────────────────
    $existing = $db->collection('users')
        ->where('email', '=', $email)
        ->limit(1)
        ->documents();

    foreach ($existing as $doc) {
        if ($doc->exists()) {
            http_response_code(409);
            echo json_encode(['error' => 'Email already registered.']);
            exit;
        }
    }

    // ── Create user document ─────────────────────────────────────────────────
    $now = new DateTimeImmutable();
    $db->collection('users')->add([
        'firstName'    => $firstName,
        'lastName'     => $lastName,
        'email'        => $email,
        'phone'        => $phone,
        'password_hash'=> password_hash($password, PASSWORD_BCRYPT),
        'role'         => $role,
        'company_id'   => null,  // linked after GHL OAuth
        'active'       => true,
        'createdAt'    => new \Google\Cloud\Core\Timestamp($now),
    ]);

    http_response_code(201);
    echo json_encode(['status' => 'success', 'message' => 'Account created.']);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Registration failed: ' . $e->getMessage()]);
}
